// dialog.cpp
#include "dialog.h"
#include "ui_dialog.h"
#include <QStandardPaths>
#include <QRegularExpression>

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
    connect(ui->btnOK, &QPushButton::clicked, this, &Dialog::registerUser);
    connect(ui->btnCancel, &QPushButton::clicked, this, &Dialog::reject); // ปิดหน้าต่าง
}

Dialog::~Dialog()
{
    delete ui;
}
void Dialog::registerUser()
{
    QString filePath = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "/users.csv";//ตนไฟล์อยู่ที่document
    QString username = ui->username->text().trimmed();
    QString passwordInput = ui->password->text();
    QString password = passwordInput.trimmed();// เงื่อนไขนี้กัน spacebar

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Error", "Username or password cannot be empty!");
        return;
    }
    if (passwordInput != password) {
        QMessageBox::warning(this, "Error", "Password must not contain spaces!");
        return;
    }
    QRegularExpression regex("^[0-9]+$");  // ใช้ Regex เช็คตัวเลข
    if (!regex.match(password).hasMatch()) {
        QMessageBox::warning(this, "Error", "Password must contain only numbers!");
        return;
    }

    // เปิดไฟล์เพื่อเพิ่มข้อมูล
    QFile file(filePath);
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "Failed to open file!");
        return;
    }

    QTextStream out(&file);
    out << username << "," << password << "\n";
    file.close();

    QMessageBox::information(this, "Success", "User registered successfully!");

    this->accept(); // ปิด Dialog หลังจากสมัครเสร็จ
}
