#include "gamechooes.h"
#include "ui_gamechooes.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QRandomGenerator>
#include <Qtimer>
#include <QInputDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , wrongAnswersCount(0) //เริ่มนับจนข้อที่0
{
    ui->setupUi(this);

    bool ok;
    int userTime = QInputDialog::getInt(this, "ตั้งเวลา", "ระบุเวลาทั้งหมด (วินาที):", 30, 10, 300, 1, &ok);
    if (!ok) close();  // ถ้าผู้ใช้กดยกเลิก ให้ปิดโปรแกรม

    timeRemaining = userTime;  // กำหนดเวลา

    // ตั้งค่า Timer
    quizTimer = new QTimer(this);
    connect(quizTimer, &QTimer::timeout, this, &MainWindow::updateTimer);
    quizTimer->start(1000);  // นับถอยหลังทุก 1 วินาที

    loadQuestionsFromCSV(); // โหลดคำถาม
    generateQuestion(); // แสดงคำถามแรก

    // เชื่อมปุ่มกับ slot
    connect(ui->btnOption1, &QPushButton::clicked, this, &MainWindow::checkAnswer);
    connect(ui->btnOption2, &QPushButton::clicked, this, &MainWindow::checkAnswer);
    connect(ui->btnOption3, &QPushButton::clicked, this, &MainWindow::checkAnswer);
    connect(ui->btnOption4, &QPushButton::clicked, this, &MainWindow::checkAnswer);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::loadQuestionsFromCSV() {
    QString filePath = "C:/Users/Tuf F15/Downloads/chooses_time count/chooes/vocabulary_list.csv"; //อย่าลืมแก้path ตามเครื่อง
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "ไม่สามารถเปิดไฟล์ vocabulary.csv ได้!");
        return;
    }

    QTextStream in(&file);
    bool firstLine = true;
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (firstLine) { // ข้ามบรรทัดแรก (header)
            firstLine = false;
            continue;
        }
        QStringList parts = line.split(',');
        if (parts.size() == 2) {
            vocabularyList.append(qMakePair(parts[0].trimmed(), parts[1].trimmed()));
        }
    }
    file.close();
}

// สุ่มคำถามใหม่
void MainWindow::generateQuestion()
{
    if (vocabularyList.size() < 4) {
        QMessageBox::warning(this, "Error", "Not enough words in vocabulary.csv");
        return;
    }

    int correctIndex = QRandomGenerator::global()->bounded(vocabularyList.size());
    QPair<QString, QString> correctWord = vocabularyList[correctIndex];

    currentQuestion.meaning = correctWord.second;
    currentQuestion.options.clear();

    QVector<int> usedIndices;
    usedIndices.append(correctIndex);

    while (currentQuestion.options.size() < 3) {
        int randomIndex = QRandomGenerator::global()->bounded(vocabularyList.size());
        if (!usedIndices.contains(randomIndex)) {
            currentQuestion.options.append(vocabularyList[randomIndex].first);
            usedIndices.append(randomIndex);
        }
    }

    // สุ่มตำแหน่งของคำตอบที่ถูกต้อง
    int correctPosition = QRandomGenerator::global()->bounded(4);
    currentQuestion.correctIndex = correctPosition;
    currentQuestion.options.insert(correctPosition, correctWord.first);

    // แสดงคำถามบน UI
    ui->lblQuestion->setText(currentQuestion.meaning);
    ui->btnOption1->setText(currentQuestion.options[0]);
    ui->btnOption2->setText(currentQuestion.options[1]);
    ui->btnOption3->setText(currentQuestion.options[2]);
    ui->btnOption4->setText(currentQuestion.options[3]);

    ui->lblResult->clear();
}

// ตรวจสอบคำตอบ
void MainWindow::checkAnswer()
{
    QPushButton *clickedButton = qobject_cast<QPushButton*>(sender());
    if (!clickedButton) return;

    int selectedIndex = -1;
    if (clickedButton == ui->btnOption1) selectedIndex = 0;
    else if (clickedButton == ui->btnOption2) selectedIndex = 1;
    else if (clickedButton == ui->btnOption3) selectedIndex = 2;
    else if (clickedButton == ui->btnOption4) selectedIndex = 3;

    if (selectedIndex == -1) return;

    if (selectedIndex == currentQuestion.correctIndex) {
        ui->lblResult->setText("✅ Correct!");
    } else {
        ui->lblResult->setText(QString("❌ Wrong! Correct answer: %1")
                                   .arg(currentQuestion.options[currentQuestion.correctIndex]));
        wrongAnswersCount++;  // เพิ่มจำนวนข้อที่ผิด
    }

    QTimer::singleShot(1500, this, &MainWindow::nextQuestion);
}

// ไปยังคำถามถัดไป
void MainWindow::nextQuestion()
{
    if (timeRemaining <= 0) return;
    generateQuestion();
}

// อัปเดตเวลาและตรวจสอบว่าหมดเวลา
void MainWindow::updateTimer()
{
    timeRemaining--;
    ui->lblTimeRemaining->setText(QString("Time Left: %1 sec").arg(timeRemaining));

    if (timeRemaining <= 0) {
        quizTimer->stop();
        QMessageBox::information(this, "Time's Up!",
                                 QString("หมดเวลา!\nคุณตอบผิดทั้งหมด: %1 ข้อ").arg(wrongAnswersCount));
        close();
    }
}
