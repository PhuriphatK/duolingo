#include "flashcardminigame.h"
#include "ui_flashcardminigame.h"
#include "flashcardresult.h"
#include <QFile>
#include <QTextStream>
#include <QCoreApplication>
#include <QMessageBox>
#include <QRandomGenerator>
#include <QTimer>
#include <algorithm>
#include <QPushButton>

FlashcardMiniGame::FlashcardMiniGame(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::flashcardminigame),
    currentRound(0),
    correctCount(0),
    wrongCount(0)
{
    ui->setupUi(this);
    loadFlashcards();
    if (flashcards.isEmpty()) {
        QMessageBox::critical(this, "Error", "No flashcards available. Please add some words first.");
        close();
        return;
    }
    // เชื่อมต่อปุ่มตัวเลือกกับ slot handleChoice()
    connect(ui->choice1, &QPushButton::clicked, this, &FlashcardMiniGame::handleChoice);
    connect(ui->choice2, &QPushButton::clicked, this, &FlashcardMiniGame::handleChoice);
    connect(ui->choice3, &QPushButton::clicked, this, &FlashcardMiniGame::handleChoice);
    connect(ui->choice4, &QPushButton::clicked, this, &FlashcardMiniGame::handleChoice);

    // เริ่มรอบแรก
    setupRound();
}

FlashcardMiniGame::~FlashcardMiniGame()
{
    delete ui;
}

void FlashcardMiniGame::loadFlashcards()
{
    // โหลด flashcard จากไฟล์ CSV ในโฟลเดอร์โปรแกรม
    QString filePath = QCoreApplication::applicationDirPath() + "/vocabulary_list.csv";
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty())
            continue;
        QStringList parts = line.split(",");
        if (parts.size() >= 2)
            flashcards.append(qMakePair(parts[0].trimmed(), parts[1].trimmed()));
    }
    file.close();
}

void FlashcardMiniGame::setupRound()
{
    // อัปเดตแสดงรอบที่กำลังเล่นอยู่
    ui->gameProgress->setText(QString("Round %1 of %2").arg(currentRound + 1).arg(totalRounds));

    // เลือก flashcard แบบสุ่มมาใช้งาน
    int idx = QRandomGenerator::global()->bounded(flashcards.size());
    QPair<QString, QString> currentCard = flashcards.at(idx);
    ui->wordLabel->setText(currentCard.first);
    correctAnswer = currentCard.second;

    // เตรียมตัวเลือกคำตอบ โดยมีคำตอบที่ถูกต้องและคำตอบที่ไม่ถูกต้องรวมกัน 4 ตัวเลือก
    QList<QString> choices;
    choices.append(correctAnswer);
    while (choices.size() < 4) {
        int randIdx = QRandomGenerator::global()->bounded(flashcards.size());
        QString candidate = flashcards.at(randIdx).second;
        if (candidate != correctAnswer && !choices.contains(candidate))
            choices.append(candidate);
    }
    // สับลำดับตัวเลือกแบบสุ่ม
    std::shuffle(choices.begin(), choices.end(), *QRandomGenerator::global());
    ui->choice1->setText(choices.at(0));
    ui->choice2->setText(choices.at(1));
    ui->choice3->setText(choices.at(2));
    ui->choice4->setText(choices.at(3));
    ui->feedbackLabel->setText("");
}

void FlashcardMiniGame::handleChoice()
{
    // ปิดการใช้งานปุ่มตัวเลือกทันที เพื่อป้องกันการคลิกซ้ำ
    ui->choice1->setEnabled(false);
    ui->choice2->setEnabled(false);
    ui->choice3->setEnabled(false);
    ui->choice4->setEnabled(false);

    // ตรวจสอบว่าปุ่มไหนถูกคลิกแล้วเปรียบเทียบคำตอบ
    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    if (!btn)
        return;
    QString chosen = btn->text();
    if (chosen == correctAnswer) {
        correctCount++;
        ui->feedbackLabel->setText("✔ Correct!");
    } else {
        wrongCount++;
        ui->feedbackLabel->setText("✘ Incorrect!");
    }
    currentRound++;

    // หน่วงเวลา 1 วินาทีแล้วตรวจสอบว่าครบจำนวนรอบหรือไม่
    QTimer::singleShot(1000, this, [this]() {
        if (currentRound >= totalRounds) {
            // ถ้าครบจำนวนรอบ ให้สร้างหน้าผลลัพธ์และปิดหน้ามินิเกม
            FlashcardResult *result = new FlashcardResult(correctCount, wrongCount);
            result->show();
            this->close();
        } else {
            // ถ้ายังไม่ครบ ให้เปิดใช้งานปุ่มใหม่และเริ่มรอบถัดไป
            ui->choice1->setEnabled(true);
            ui->choice2->setEnabled(true);
            ui->choice3->setEnabled(true);
            ui->choice4->setEnabled(true);
            setupRound();
        }
    });
}
