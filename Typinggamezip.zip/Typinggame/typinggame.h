#ifndef TYPINGGAME_H
#define TYPINGGAME_H

#include <QWidget>
#include <QTimer>
#include <QTime>
#include <QStringList>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

class TypingGame : public QWidget {
    Q_OBJECT

public:
    TypingGame(QWidget *parent = nullptr);

private slots:
    void startGame();
    void checkInput(const QString &text);
    void updateTimer();

private:
    QLabel *textDisplay;
    QLabel *timerDisplay;
    QLabel *resultDisplay;
    QLineEdit *inputField;
    QPushButton *startButton;

    QTimer *timer;
    QTime startTime;
    QStringList texts;
    QString currentText;
    int mistakeCount;

    void setupUI();
    void endGame();
};

#endif // TYPINGGAME_H
