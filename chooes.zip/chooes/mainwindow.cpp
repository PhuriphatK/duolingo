#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QTimer>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , currentQuestionIndex(0)
{
    ui->setupUi(this);

    loadQuestions(); // โหลดคำถาม
    displayQuestion(); // แสดงคำถามแรก

    // เชื่อมปุ่มกับ slot
    connect(ui->btnOption1, &QPushButton::clicked, this, &MainWindow::checkAnswer);
    connect(ui->btnOption2, &QPushButton::clicked, this, &MainWindow::checkAnswer);
    connect(ui->btnOption3, &QPushButton::clicked, this, &MainWindow::checkAnswer);
    connect(ui->btnOption4, &QPushButton::clicked, this, &MainWindow::checkAnswer);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// โหลดชุดคำถาม
void MainWindow::loadQuestions()
{
    questions.append({"have the ability to", {"capable", "contribute", "determine", "extend"}, 0});
    questions.append({"discuss to reach agreement", {"predict", "negotiate", "recommend", "provoke"}, 1});
    questions.append({"strive against others", {"demonstrate", "convince", "compete", "eliminate"}, 2});
    questions.append({"produce or create", {"generate", "negotiate", "persuade", "remove"}, 0});
}

// แสดงคำถามบน UI
void MainWindow::displayQuestion()
{
    if (currentQuestionIndex >= questions.size()) {
        QMessageBox::information(this, "Quiz", "You have completed all questions!");
        close();
        return;
    }

    const Question &q = questions[currentQuestionIndex];
    ui->lblQuestion->setText(q.questionText);
    ui->btnOption1->setText(q.options[0]);
    ui->btnOption2->setText(q.options[1]);
    ui->btnOption3->setText(q.options[2]);
    ui->btnOption4->setText(q.options[3]);

    ui->lblResult->clear(); // ล้างข้อความผลลัพธ์
}

// ตรวจสอบคำตอบ
void MainWindow::checkAnswer()
{
    QPushButton *clickedButton = qobject_cast<QPushButton*>(sender());
    if (!clickedButton) return;

    int selectedIndex = -1;
    if (clickedButton == ui->btnOption1) selectedIndex = 0;
    else if (clickedButton == ui->btnOption2) selectedIndex = 1;
    else if (clickedButton == ui->btnOption3) selectedIndex = 2;
    else if (clickedButton == ui->btnOption4) selectedIndex = 3;

    if (selectedIndex == -1) return;

    const Question &q = questions[currentQuestionIndex];

    if (selectedIndex == q.correctIndex) {
        ui->lblResult->setText("Correct!");
        QTimer::singleShot(1000, this, &MainWindow::nextQuestion);
    } else {
        ui->lblResult->setText(QString("Wrong! Correct answer: %1").arg(q.options[q.correctIndex]));
        QTimer::singleShot(2000, this, &MainWindow::nextQuestion);
    }
}

// ไปยังคำถามถัดไป
void MainWindow::nextQuestion()
{
    currentQuestionIndex++;
    displayQuestion();
}
