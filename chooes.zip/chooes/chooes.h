#ifndef CHOOES_H
#define CHOOES_H

#include <QMainWindow>
#include <QVector>
#include <QString>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

struct Question {
    QString meaning;        // ความหมายของคำศัพท์
    QVector<QString> options; // ตัวเลือก 4 ข้อ
    int correctIndex;        // ตำแหน่งของคำตอบที่ถูกต้อง
};

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void loadQuestionsFromCSV(); // โหลดคำศัพท์จาก CSV
    void generateQuestion(); // สุ่มคำถาม
    void checkAnswer(); // ตรวจสอบคำตอบ
    void nextQuestion(); // ไปยังคำถามถัดไป
    void updateTimer(); //ตัวจับเวลา

private:
    Ui::MainWindow *ui;
    QVector<QPair<QString, QString>> vocabularyList; // เก็บ word และ meaning
    Question currentQuestion; // คำถามปัจจุบัน
    int wrongAnswersCount;        // จำนวนข้อที่ผิด
    QTimer *quizTimer;            // ตัวจับเวลา
    int timeRemaining;            // เวลาที่เหลือ
};

#endif // CHOOES_H
