#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void checkAnswer(); // ตรวจสอบคำตอบ
    void nextQuestion(); // ไปยังคำถามถัดไป

private:
    Ui::MainWindow *ui;

    struct Question {
        QString questionText;
        QStringList options;
        int correctIndex;
    };

    QVector<Question> questions;
    int currentQuestionIndex;

    void loadQuestions();
    void displayQuestion();
};

#endif // MAINWINDOW_H
